import Learning from "../components/learning/Learning";


function First() {
    return (
      <div>
      <Learning/>
      </div>
    );
  }
  
  export default First; 
  