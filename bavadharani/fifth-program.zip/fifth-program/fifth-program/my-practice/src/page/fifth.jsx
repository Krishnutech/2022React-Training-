
import Detail from "../components/detail/Detail";




function Fifth() {
    return (
      <div>
      <Detail/>
      </div>
    );
  }
  
  export default Fifth; 