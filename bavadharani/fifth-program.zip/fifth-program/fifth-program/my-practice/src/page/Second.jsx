import Content from "../components/content/Content";


function Second() {
    return (
      <div>
        <Content/>
      </div>
    );
  }
  
  export default Second; 
  