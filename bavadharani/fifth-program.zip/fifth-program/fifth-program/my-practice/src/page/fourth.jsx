import About from "../components/about/About";



function Fourth() {
    return (
      <div>
      <About/>
      </div>
    );
  }
  
  export default Fourth; 
  