
import Home from "../components/home/Home";


function Third() {
    return (
      <div>
      <Home/>
      </div>
    );
  }
  
  export default Third; 
  