

function Detail() {
    return (
      <div>   
   
              <div className="box1">
               <div className="box2">            
                 <h1>fifth pagepage</h1>          
               </div>               
         </div>  
          
       </div>
     );
   }
   export default Detail;
   
   
   
   
   
   
   
   
   
   
   